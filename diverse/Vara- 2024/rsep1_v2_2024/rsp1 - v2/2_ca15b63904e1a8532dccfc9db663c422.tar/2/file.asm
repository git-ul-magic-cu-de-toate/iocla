extern puts
extern printf


section .rodata
    arr1 dd 9, 11, 13, 15, 16, 18, 20
    len1 equ 7
    arr2 dd 11, 22, 33, 44, 55, 66, 77, 88, 99
    len2 equ 9
    arr3 dw 2, 4, 6, 8, 9, 11
    len3 equ 6
    odd_fmt db "number of odd numbers in array: %u", 10, 0
    even_fmt db "number of even numbers in array: %u", 10, 0


section .text
global main


num_bits:
    push ebp
    mov ebp, esp

    ; TODO a: Implement num_bits(array, len, odd) to return the
    ; number of odd/even numbers in array of len integer (4 bytes) elements.

    leave
    ret


num_odd:
    push ebp
    mov ebp, esp

    ; TODO b: Implement num_odd(array, len) as wrapper over num_bits.

    leave
    ret


num_even:
    push ebp
    mov ebp, esp

    ; TODO b: Implement num_even(array, len) as wrapper over num_bits.

    leave
    ret


num_bits_size:
    push ebp
    mov ebp, esp

    ; TODO c: Implement num_bits_size(array, size, len, odd) to return the
    ; number of odd/even numbers in array of len elements of size.

    leave
    ret


main:
    push ebp
    mov ebp, esp

    push dword 1
    push dword len1
    push dword arr1
    call num_bits
    add esp, 12

    push eax
    push odd_fmt
    call printf
    add esp, 8

    push dword len1
    push dword arr1
    call num_odd
    add esp, 8

    push eax
    push odd_fmt
    call printf
    add esp, 8

    push dword len1
    push dword arr1
    call num_even
    add esp, 8

    push eax
    push even_fmt
    call printf
    add esp, 8

    push dword 1
    push dword len3
    push dword 2
    push dword arr3
    call num_bits_size
    add esp, 16

    push eax
    push odd_fmt
    call printf
    add esp, 8

    ; Return 0.
    xor eax, eax
    leave
    ret
