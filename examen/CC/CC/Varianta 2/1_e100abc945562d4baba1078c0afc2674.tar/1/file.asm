%include "./utils/printf32.asm"

section .data
    temp_len dd 8
    temp_1 dd 5, 7, -2, 10, -4, 2, 3, 0
    temp_2 dd 1, 3, 0, -1, -1, 2, 3, 5

section .bss
    ; TODO a: Reserve space for merged_temp


section .text
global main

main:
    push ebp
    mov ebp, esp


    ; TODO a: Populate and print merged_temp


    ; TODO b: Get minimum value from the vector



    ; TODO c: Get number of values >= 0



    ; TODO d: Reverse the merged_temp array


    ; Return 0.
    xor eax, eax
    leave
    ret
