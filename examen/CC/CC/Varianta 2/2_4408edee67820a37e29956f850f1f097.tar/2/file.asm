extern printf

section .data

fmt_int db "%d ", 0
fmt_newline db  10,0
fmt_time db "%d:%d:%d", 10, 0

seconds_int dd 45296
seconds_arr dd 0, 60, 61, 3661, 7322, 10983, 14644, 18305, 21966, 86399
len equ 10

section .bss

ss_t resd 1
mm_t resd 1
hh_t resd 1

section .text
global main

;TODO a: Implement `void print_array(int *arr, int len)` function:
; that prints the all `len` integer elements of array `arr` on the same line separated by a space.
; print a new line at the end.
; It is mandatory to use `printf` for printing. You may use `fmt_int` and `fmt_newline` for formatting.

print_array:
    push ebp
    mov ebp, esp


    leave
    ret

; TODO b: Implement `void convert_time(int s, int *hh, int *mm, int *ss)` function
; that converts an amount of `s` seconds into (hh, mm, ss) format where:
; hh: is the number of hours that can be found in `s`
; mm: is the number of minutes left in `s` after substracting the hours `hh`
; ss: is the number of seconds left in `s` after substracting the hours `hh` and minutes `mm`
; e.g:
; convert_time(0, &hh, &mm, &ss)    => (0, 0, 0)
; convert_time(61, &hh, &mm, &ss)   => (0, 1, 1)
; convert_time(3661, &hh, &mm, &&ss) => (1, 1, 1)

; NOTE: For `div` instruction one can place the dividend in `edx:eax`, divisor in register or memory
; and the result be placed like this: Quotient in EAX, Remainder in EDX

convert_time:
    push ebp
    mov ebp, esp


    leave
    ret

main:
    push ebp
    mov ebp, esp

    ; TODO a: print `seconds_arr` array by calling print_array(seconds_arr, len)
    ; `seconds_arr` and `len` are defined in `.data` section


    ; TODO b: compute the number of (hh, mm, ss) to be found in `seconds_int` by calling `convert_time` function
    ; Use `ss_t`, `mm_t`, `hh_t` memory areas to store the result.
    ; Use `printf` to display the result. Use `fmt_time` for formatting


    ; TODO c: Convert all `len` elements of `seconds_arr` to (hh, mm, ss) format and display the result
    ; For each element, store the result in `ss_t`, `mm_t`, `hh_t` memory areas
    ; and then print it before moving to the nexte element
    ; Use `printf` to display the result. Use `fmt_time` for formatting


    ; Return 0.
    xor eax, eax
    leave
    ret
