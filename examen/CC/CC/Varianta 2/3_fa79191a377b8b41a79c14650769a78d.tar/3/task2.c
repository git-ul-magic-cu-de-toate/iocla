#include <stdio.h>

// TODO: Freestyle starts here
int task2(int a, int b, int *sum)
{

}
