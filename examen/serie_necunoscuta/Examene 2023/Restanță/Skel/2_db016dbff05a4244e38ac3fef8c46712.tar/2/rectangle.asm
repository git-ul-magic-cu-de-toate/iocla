extern printf
extern puts


section .rodata
    perimeter_msg     db "perimter is %zu", 10, 0
    area_msg     db "area is %zu", 10, 0
    perimeter_array_msg db "perimeter array is: ", 0
    area_array_msg db "area array is: ", 0
    simple_fmt   db "%zu ", 0
    empty_str   db "", 0
    first_array dd 10, 20, 30, 40, 50
    second_array dd 20, 30, 40, 50, 60
    len equ 5


section .bss
    perimeter_array resd 5
    area_array resd 5


section .text
global main


perimeter:
    push ebp
    mov ebp, esp

    ; TODO a: Implement perimeter(unsigned int first, unsigned int second) function.

    leave
    ret


area:
    push ebp
    mov ebp, esp

    ; TODO b: Implement perimeter(unsigned int first, unsigned int second) function.

    leave
    ret


print_array:
    push ebp
    mov ebp, esp

    push dword [ebp+8]
    call printf
    add esp, 4

    mov ebx, [ebp+12]
    xor ecx, ecx
loop:
    push ebx
    push ecx
    push dword [ebx + ecx * 4]
    push simple_fmt
    call printf
    add esp, 8

    pop ecx
    pop ebx
    inc ecx
    cmp ecx, [ebp+16]
    jne loop

    push empty_str
    call puts
    add esp, 4

    leave
    ret


main:
    push ebp
    mov ebp, esp


    ; TODO a: Call perimeter() function and print result.


    ; TODO b: Call area() function and print result.


    ; TODO c: Fill perimiter_array and area_array by calling perimeter()
    ; and area() functions on first_array and second_array.
    ; Print perimeter_array and area_array using print_array() function.


    ; Return 0.
    xor eax, eax
    leave
    ret
