/**
 * !!! IMPORTANT !!!
 *
 * DO NOT modify this file
 */

char const *try = "Try me, bro!!!";
const int vvv = 1;
unsigned vvvv;
unsigned short vvvvv = 0;
long vvvvvv = 123456;
long long vvvvvvv = 1234567;

struct {
    long long d;
    char c : 3;
    int b : 2;
    int a : 1;
} S;

struct {
    long long l;
    char c;
    int i1;
    int i2;
} SS = {10, 'b', 1, 1};

struct {
    long long l;
    int i1;
    char c;
} SSS;

const char *medication[][2] = {
    {"e", "3"}, {"o", "0"}, {"i", "1"}, {"ate", "8"}, {"g", "4"},
};
