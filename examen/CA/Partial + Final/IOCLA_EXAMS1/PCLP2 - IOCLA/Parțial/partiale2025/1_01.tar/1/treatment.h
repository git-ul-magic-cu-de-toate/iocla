#ifndef __FILE_H__
#define __FILE_H__

const char *sickString = "H3lp m3 d0ct0r, I am r3ally s1ck. I h8 spr1n4";
long funcIdx = 0;

extern const char *medication[][2];

void show_prescription();
int heal(char const **healedString);


#endif // __FILE_H__
