#include <stdio.h>

#include "treatment.h"

/**
 * !!! IMPORTANT !!!
 * It is mandatory to use `goto` to implement each loop you will need
 *
 * You are NOT allowed to modify function signatures. You can create new
 * functions if needed.
 */

void show_prescription() {
    /**
     * TODO b: Display all variables from each data section according to the
     * instructions using any tool you consider necessary (hint: gdb, nm,
     * objdump)
     *
     * It is mandatory to use the dataSections array
     *
     * !!! IMPORTANT !!!
     * The variables that need to be displayed are part of this executable
     * before doing any changes to the code. All other variables that you might
     * use for solving the tasks should not appear in the solution of this task.
     */
    char dataSections[][8] = {".data", ".rodata", ".bss"};

    printf("%s: Remove this print after implementing the function\n", __func__);
}

int heal(char const **healedString) {
    /**
     * TODO c: Implement the heal function that will replace improper
     * characters of the sickString with proper characters, as specified in the
     * problem statement
     *
     * It is mandatory to allocate the minimum amount of memory for
     * healedString in the worst-case scenario (i.e., each 'bad' character in
     * sickString is replaced with the longest 'good' character/sequence)
     *
     * The function will return 0 if the healing process is successful and -1
     * for any other problem that may arise
     *
     * !!! IMPORTANT !!!
     * You will use only the sickString variable without modifying it
     */

    printf("%s: Remove this print after implementing the function\n", __func__);
    return 0;
}

int main(void) {
    for (funcIdx = 0; funcIdx < 2; funcIdx++) {
        switch (funcIdx) {
        case 0:
            show_prescription();
            break;
        case 1:
            char const *healedString;
            if (heal(&healedString) == 0) {
                printf("Healed string: %s\n", healedString);
            } else {
                printf("Healing process failed\n");
            }
            break;
        }
    }

    return 0;
}
