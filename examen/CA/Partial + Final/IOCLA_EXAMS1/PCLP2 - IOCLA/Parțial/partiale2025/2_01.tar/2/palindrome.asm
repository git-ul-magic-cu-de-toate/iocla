%include "printf32.asm"

section .data
    byte_array db 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF
    short_array dw 0x0110, 0x0101, 0x2020, 0x5234, 0x6134, 0xCDDC, 0x0D0D, 0x0E0E, 0x0F0F, 0xAAAA, 0xBBBB, 0xCCCC, 0xDDDD, 0xEEEE, 0xFFFF
    int_array dd 0x00011000, 0xABABABAB, 0x22331222, 0xFEFEEFEF, 0xAAAAAAAA, 0xBBB00BBB, 0xCCACCACC, 0xDDABBADD, 0xFFFFFFFF

section .bss
    ; TODO c: Reserve space for the 2D array specified in the problem statement

section .text
global main
extern printf

show_byte_palindromes:
    push ebp
    mov ebp, esp

    ; TODO a: Iterate through each of the arrays (byte_array, short_array, int_array) and 
    ;   display each element that is a palindrome at the byte level

    xor eax, eax
    leave
    ret

show_nibble_palindromes:
    push ebp
    mov ebp, esp

    ; TODO a: Iterate through each of the arrays (byte_array, short_array, int_array) and 
    ;   display each element that is a palindrome at the nibble level

    xor eax, eax
    leave
    ret

construct_2d_palindromes_array:
    push ebp
    mov ebp, esp

    ; TODO c: Populate the 2D array declared in the .bss section according to the problem statement

    xor eax, eax
    leave
    ret

show_2d_palindromes_array:
    push ebp
    mov ebp, esp

    ; TODO c: Iterate through the 2D array and display the elements according to the problem statement, 
    ;   displaying the elements as a matrix

    xor eax, eax
    leave
    ret

main:
    push ebp
    mov ebp, esp

    ; TODO a: Call show_byte_palindromes

    ; TODO b: Call show_nibble_palindromes

    ; TODO c: Call construct_2d_palindromes_array

    ; TODO c: Call show_2d_palindromes_array

    xor eax, eax
    leave
    ret
