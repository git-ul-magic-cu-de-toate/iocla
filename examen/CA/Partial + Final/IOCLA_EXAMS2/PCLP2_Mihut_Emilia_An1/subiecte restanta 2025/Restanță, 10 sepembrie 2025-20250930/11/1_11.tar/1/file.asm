%include "printf32.asm"

struc line_structured
    key: resd 1
    value: resd 1
endstruc

section .rodata
    x: dd 0x16
    kp: db 0x73, 0x6d, 0x74, 0x68, 0x0
    vp: db 0x6f, 0x74, 0x68, 0x65, 0x72, 0x0
    line_sample:
        istruc line_structured
            at key, dd kp
            at value, dd vp
        iend

section .text
extern printf
global main

main:
    push ebp
    mov ebp, esp


    ; TODO a: Determine the integer log base 10 of `x`.
    ; NOTE: You must print the result afterwards.



    ; TODO b: Parse the `line_sample` struct into a
    ; key=value type of string, named `line`.
    ; NOTE: You must print `line` afterwards.



    ; TODO c: Print the absolute value of the size difference between
    ; `line_sample` and `line`.



    ; TODO d: Print the ratio between the size of `line_sample`
    ; and the size of `line`.



    ; Return 0.
    xor eax, eax
    leave
    ret
