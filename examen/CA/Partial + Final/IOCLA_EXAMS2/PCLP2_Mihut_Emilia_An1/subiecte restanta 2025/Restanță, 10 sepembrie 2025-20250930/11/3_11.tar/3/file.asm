section .data
    ; TODO a: TODO


section .text
global main

main:
    push ebp
    mov ebp, esp


    ; TODO b: TODO



    ; TODO c: TODO



    ; Return 0.
    xor eax, eax
    leave
    ret
