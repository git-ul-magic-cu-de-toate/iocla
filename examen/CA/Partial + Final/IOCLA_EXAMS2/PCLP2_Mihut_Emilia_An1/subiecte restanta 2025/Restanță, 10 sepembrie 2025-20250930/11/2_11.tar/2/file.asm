section .text

; TODO a: Implement `void special_print(int a, int b)` which prints
; the sum of a and b to stderr.

special_print:
    push ebp
    mov ebp, esp

    leave
    ret

; TODO b: Implement `void special_modify(void)` which modifies
; the global variable `invisible` declared in main.c to 10.

special_modify:
    push ebp
    mov ebp, esp

    leave
    ret

; TODO c: Implement `void show_cwd(void)` which prints
; the current working directory.

show_cwd:
    push ebp
    mov ebp, esp

    leave
    ret

