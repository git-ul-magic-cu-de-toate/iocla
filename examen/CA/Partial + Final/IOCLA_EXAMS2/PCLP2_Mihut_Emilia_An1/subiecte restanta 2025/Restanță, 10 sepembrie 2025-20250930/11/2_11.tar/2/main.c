#include <stdio.h>

static int invisible = 4;

int main(void)
{
    // TODO a: Call `special_print()` using 9 for `a` and 7 for `b`.

    // TODO b: Call `special_modify()` without any arguments and without
    // expecting any return value.
    // NOTE: You must print `invisible` afterwards.

    // TODO c: Call `show_cwd()` without any arguments and without
    // expecting any return value.

    return 0;
}
