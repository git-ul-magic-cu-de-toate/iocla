%include "printf32.asm"

struc line_parsed
    key: resd 1
    value: resd 1
endstruc

section .rodata
    x: dd 0x16

section .data
    line: db 0x73, 0x6d, 0x74, 0x68, 0x3d, 0x6f, 0x74, 0x68, 0x65, 0x72, 0x0

section .text
extern printf
global main

main:
    push ebp
    mov ebp, esp


    ; TODO a: Determine the integer log base 2 of `x`.
    ; NOTE: You must print the result afterwards.



    ; TODO b: Determine the length of the key and value
    ; stored in the `line` array.
    ; NOTE: You must print them.



    ; TODO c: Populate a new struct of type `line_parsed`
    ; with the key and value stored in the `line` array.
    ; NOTE: You must print the struct afterwards.



    ; TODO d: Print the size of the struct created at
    ; task c in bytes.



    ; Return 0.
    xor eax, eax
    leave
    ret
