section .text

; TODO a: Implement `void special_print(int a, int b)` which prints
; the sum of a and b to stdout.

special_print:
    push ebp
    mov ebp, esp

    leave
    ret

; TODO b: Implement `void special_modify(void)` which modifies
; the global variable `visible` declared in main.c to 10.

special_modify:
    push ebp
    mov ebp, esp

    leave
    ret

; TODO c: Implement `void show_time(void)` which prints
; the number of seconds passed since the epoch.

show_time:
    push ebp
    mov ebp, esp

    leave
    ret

