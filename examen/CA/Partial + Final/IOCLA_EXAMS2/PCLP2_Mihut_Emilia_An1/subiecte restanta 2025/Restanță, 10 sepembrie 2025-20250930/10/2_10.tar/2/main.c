#include <stdio.h>

int visible = 4;

int main(void)
{
    // TODO a: Call `special_print()` using 10 for `a` and 6 for `b`.

    // TODO b: Call `special_modify()` without any arguments and without
    // expecting any return value.
    // NOTE: You must print `visible` afterwards.

    // TODO c: Call `show_time()` without any arguments and without
    // expecting any return value.

    return 0;
}
