section .data
    arr: dd 1, 16, 7, 10, 22, 23, 8, 30
    n: dd 8

section .text
global main

; TODO a: Implement `int sum(int *arr, int n)` which returns
; the sum of the `n` elements from the `arr` array.

sum:
    push ebp
    mov ebp, esp

    leave
    ret

; TODO b: Implement RECURSIVELY int sum(int *arr, int n)` which returns
; the sum of the `n` elements from the `arr` array.

sum_rec:
    push ebp
    mov ebp, esp

    leave
    ret


main:
    push ebp
    mov ebp, esp


    ; TODO a: Call `sum` using `arr` and `n` from the `.data` section.
    ; NOTE: You must print the result.



    ; TODO b: Call `sum_rec` using `arr` and `n` from the `.data` section.
    ; NOTE: You must print the result.



    ; TODO c: Call `get_nano()` for each of the functions above
    ; in order to get the number of nanoseconds each one of them
    ; took to run.
    ; NOTE: You must print the name of the function that took
    ; less seconds to run.



    ; Return 0.
    xor eax, eax
    leave
    ret
