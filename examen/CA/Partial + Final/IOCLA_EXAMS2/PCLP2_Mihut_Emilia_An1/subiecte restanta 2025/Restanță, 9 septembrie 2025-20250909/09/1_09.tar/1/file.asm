%include "printf32.asm"

section .rodata
    weird: db "i<3you", 10, 0


section .text
extern printf
global main

main:
    push ebp
    mov ebp, esp


    ; TODO a: Determine whether the signed integer saved at the
    ; middle of the `weird` array is odd or even.
    ; NOTE: You must print "The number <nr> is odd" if nr
    ; is odd, or "The number <nr> is even", otherwise.



    ; TODO b: Determine whether the signed quad word
    ; represented by the `weird` array is positive.
    ; NOTE: You must print "The number <nr> is positive" if nr
    ; is higher than 0, or "The number <nr> is negative", otherwise.



    ; TODO c: Determine the number of unset bits inside the
    ; `weird` array.
    ; NOTE: You must print the result.



    ; TODO d: Print the address of the stack frame for
    ; the function that calls `main`.



    ; Return 0.
    xor eax, eax
    leave
    ret
