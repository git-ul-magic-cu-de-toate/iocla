/* DO NOT MODIFY THIS FILE */
#include <stdio.h>

int main()
{
#ifdef PRINT_HELLO
	printf("Hello, world!\n");
#endif

	printf("Goodbye, world!\n");
	return 0;
}
