%include "printf32.asm"
extern printf

section .data
M dd -20
N dd 90
in_len dd 0

arr dd -30, -20, -10, 40, 50, 60, 70, 80, 90, 100
len equ 10

section .bss
res: resd len


; TODO b: Declarati variabla de tip `double word` cu numele `in_len`

; TODO c: Declarati vectorul de intregi (`double word`) `res` cu maximum `len` elemente

section .text
global main

main:
    push ebp
    mov ebp, esp

    ; TODO a: Determinați cum este plasat numarul arr[0] relativ la intervalul [M, N], unde M < N. Afisati:
    ; -1, daca numarul arr[0] se afla la stanga intervalului (arr[0] < M)
    ; 0, daca numarul arr[0] se gaseste in intervalul [M, N] (M <= arr[0] <= N)
    ; 1, daca numarul arr[0] se gaseste la dreapta intervalului (arr[0] > N)

;     mov ebx, [ebp + 8]
;     xor ecx, ecx
;     xor eax, eax
;     xor edx, edx
;     xor edi, edi
;     mov eax, [arr]

;     cmp eax, [M]
;     jl ceva

;     cmp eax, [N]
;     jg ceva1

;     jmp altceva

; ceva:
;     mov edi, -1
;     jmp altceva    


; ceva1:
;     mov edi, 1
;     jmp altceva     
    

; altceva:
;     PRINTF32 `%d\n\x0`, edi
    

    ; TODO b: Calculati si afisati numarul elementelor din vectorul `arr` care se gasesc
    ; in intervalul [M, N]. Retineti aceasta valoare in variabila `in_len` din sectiunea `.bss`.
;     mov ebx, [ebp + 8]
;     xor ecx, ecx
;     xor eax, eax
;     mov edx, len
;     xor edi, edi
    

; while:
   
;     xor eax, eax
;     mov eax, [arr + ecx * 4]

;     cmp eax, [N]
;     jg altceva

;     cmp eax, [M]
;     jl altceva

; ceva:
;     inc edi

; altceva:
;     inc ecx
;     cmp ecx, len
;     jl while


;     mov [in_len], edi
;     PRINTF32 `%d\n\x0`, [in_len]
    ; TODO c: Completati vectorul `res` de dimensiune maxima `len` cu elementele din
    ; vectorul `arr` care se gasesc in intervalul [M, N].
    ; Declarati vectorul `res` in sectiunea `bss`.

    mov ebx, [ebp + 8]
    xor ecx, ecx
    xor eax, eax
    mov edx, len
    xor edi, edi
    

while:
   
    xor eax, eax
    mov eax, [arr + ecx * 4]

    cmp eax, [N]
    jg altceva

    cmp eax, [M]
    jl altceva

ceva:  
    mov [res + edi * 4], eax
    inc edi

altceva:
    
    inc ecx
    cmp ecx, len
    jl while

    mov [in_len], edi


    ; TODO d: Afisati vectorul `res` de dimensiune `in_len` cu elementele
    ; pe aceeasi linie separate de un spatiu
    xor ebx, ebx
    mov ebx, [ebp + 12]
    mov ebx, [res]
    xor ecx, ecx
    xor edi, edi

while2:
    xor eax, eax
    mov eax, [res + 4 * ecx]
    PRINTF32 `%d \x0`, eax

    inc ecx
    cmp ecx, [in_len]
    jl while2


    ; Return 0.
    xor eax, eax
    leave
    ret
